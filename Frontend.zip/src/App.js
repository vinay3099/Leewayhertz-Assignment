import './App.css';
import User from './User';

function App() {
  return (
    <User/>
  );
}

export default App;