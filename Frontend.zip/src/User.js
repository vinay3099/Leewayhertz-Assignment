import React, { useState } from 'react';
import axios from 'axios';

import'./user.css'
const User = () => {
    const [newUser, setNewUser] = useState(
        {
            firstname: '',
            lastname: '',
            emailid:'',
            phonenumber:'',
            photo: '',
        }
    );

    
    

    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('photo', newUser.photo);
        formData.append('firstname', newUser.firstname);
        formData.append('lastname', newUser.lastname);
        formData.append('emailid', newUser.emailid);
        formData.append('phonenumber', newUser.phonenumber);

        axios.post('http://localhost:5000/users/add/', formData)
             .then(res => {
                console.log(res);
               
             })
             .catch(err => {
                console.log(err);
             });
    }


   

    const handleChange = (e) => {
        setNewUser({...newUser, [e.target.name]: e.target.value});
    }

    const handlePhoto = (e) => {
        setNewUser({...newUser, photo: e.target.files[0]});
    }

    return (
        <div className="app">
         <form  onSubmit={handleSubmit} encType='multipart/form-data'>
           
          

           <div className="form-input">
            <input 
               type="text"
               placeholder="First Name"
               name="firstname"
               value={newUser.firstname}
               onChange={handleChange}
           />
           </div>
           <div className="form-input">
            <input 
               type="text"
               placeholder="Last Name"
               name="lastname"
               value={newUser.lastname}
               onChange={handleChange}
           />
           </div>
           <div className="form-input">
            <input 
               type="text"
               placeholder="Email Id"
               name="emailid"
               value={newUser.emailid}
               onChange={handleChange}
           />
           </div>

           <div className="form-input">
           <input 
               type="text"
               name="phonenumber"
               placeholder="Phone Number"
               value={newUser.phonenumber}
               onChange={handleChange}
           />
           </div>
           
           <div className="form-input">
           <input 
               type="file" 
               accept=".png, .jpg, .jpeg"
               name="photo"
               onChange={handlePhoto}
           />
           </div>

           <button>submit</button>
           
       </form>
        </div>
        
    );
}

export default User;